rm -rf autom4te.cache/

aclocal
autoconf
autoheader
automake -a
